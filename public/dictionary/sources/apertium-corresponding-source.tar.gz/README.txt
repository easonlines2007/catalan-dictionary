Apertium corresponding source
==============================

This archive contains the exact GPL-2.0 Apertium source files used by
the Catalan Dictionary PWA, both upstream COPYING files, the frequency
corpus used for ranking, and the complete standard-library builder.
Place the extracted `work/sources` directories at the paths recorded in
sources.lock.json, add the separately licensed Wiktionary/FreeDict inputs,
then run `python3 scripts/dictionary/build.py`.
